ARCH = 'x86_64'
